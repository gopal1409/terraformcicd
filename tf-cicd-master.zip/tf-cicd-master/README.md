# tf-cicd
Automating Terraform deployments on Azure using Jenkins
