#!/bin/bash

rm -r .terraform
rm *.tfstate
rm *.tfstate.*
rm *.tfplan
