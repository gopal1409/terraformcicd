# Create a Virtual Network in Azure with Terraform

**This module creates a virtual network with a subnet.**



